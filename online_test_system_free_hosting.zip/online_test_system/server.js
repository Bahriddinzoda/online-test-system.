const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.json({ limit: "30kb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const sessions = new Map();

const QUESTION_BANK = [
  {q:"Технологияи информатсионӣ чиро меомӯзад?",o:["Ҷамъоварӣ, нигоҳдорӣ, коркард ва интиқоли иттилоот","Танҳо таъмири компютер","Танҳо ҳисобҳои математикӣ","Танҳо сохтани дастгоҳҳои барқӣ"],a:0},
  {q:"Қисми асосии коркарди маълумот дар компютер кадом аст?",o:["Монитор","Протсессор","Клавиатура","Принтер"],a:1},
  {q:"Кадоме аз инҳо дастгоҳи воридкунии маълумот аст?",o:["Монитор","Принтер","Клавиатура","Баландгӯяк"],a:2},
  {q:"Системаи оператсионӣ барои чӣ лозим аст?",o:["Танҳо навиштани матн","Идоракунии кори компютер ва захираҳои он","Танҳо чоп кардани ҳуҷҷат","Танҳо тамошои видео"],a:1},
  {q:"Воҳиди хурдтарини иттилооти рақамӣ кадом аст?",o:["Байт","Килобайт","Бит","Мегабайт"],a:2},
  {q:"Кадом барнома барои коркарди матн истифода мешавад?",o:["Microsoft Excel","Microsoft Word","Microsoft Paint","Microsoft Access"],a:1},
  {q:"Васеъшавии маъмулии ҳуҷҷати муосири Word кадом аст?",o:[".xlsx",".pptx",".docx",".jpg"],a:2},
  {q:"Кадом барнома барои сохтани ҷадвалҳои электронӣ истифода мешавад?",o:["Microsoft Word","Microsoft Excel","Microsoft PowerPoint","Microsoft Outlook"],a:1},
  {q:"Формула дар Excel одатан бо кадом аломат оғоз мешавад?",o:["+","=","#","&"],a:1},
  {q:"Microsoft PowerPoint асосан барои чӣ истифода мешавад?",o:["Сохтани презентатсия","Барномасозӣ","Коркарди пойгоҳи додаҳо","Таҳрири садо"],a:0},
  {q:"Кадоме аз инҳо браузери интернетӣ мебошад?",o:["Google Chrome","Microsoft Excel","Adobe Photoshop","Microsoft Word"],a:0},
  {q:"Интернет чист?",o:["Як барномаи матнӣ","Шабакаи ҷаҳонии компютерҳо","Танҳо як сомона","Як намуди принтер"],a:1},
  {q:"Вируси компютерӣ чист?",o:["Қисми таҷҳизоти компютер","Барномаи зараровар","Системаи оператсионӣ","Дастгоҳи нигоҳдорӣ"],a:1},
  {q:"Хотираи RAM чӣ вазифа дорад?",o:["Нигоҳдории муваққатии маълумоти истифодашаванда","Чоп кардани ҳуҷҷатҳо","Намоиши тасвир","Пайвастшавӣ ба интернет"],a:0},
  {q:"Кадом дастгоҳ барои нигоҳдории дарозмуддати маълумот истифода мешавад?",o:["RAM","SSD","Протсессор","Монитор"],a:1},
  {q:"Кадом миёнабур барои нусхабардории матни интихобшуда истифода мешавад?",o:["Ctrl + X","Ctrl + V","Ctrl + C","Ctrl + Z"],a:2},
  {q:"Кадом миёнабур барои гузоштани матни нусхабардоришуда истифода мешавад?",o:["Ctrl + V","Ctrl + C","Ctrl + A","Ctrl + P"],a:0},
  {q:"Кадом миёнабур амали охиринро бекор мекунад?",o:["Ctrl + S","Ctrl + Z","Ctrl + N","Ctrl + O"],a:1},
  {q:"Кадоме аз инҳо дастгоҳи барориши иттилоот аст?",o:["Муш","Клавиатура","Сканер","Монитор"],a:3},
  {q:"Почтаи электронӣ барои чӣ истифода мешавад?",o:["Танҳо таҳрири расм","Фиристодан ва қабул кардани паёмҳои электронӣ","Танҳо ҳисоб кардани рақамҳо","Идоракунии таҷҳизоти чопӣ"],a:1}
];

function token() { return crypto.randomBytes(24).toString("hex"); }
function pin() { return String(Math.floor(100000 + Math.random() * 900000)); }
function cleanName(v) { return String(v || "").trim().replace(/\s+/g, " ").slice(0, 70); }
function grade(score) {
  if (score >= 90) return "АЪЛО";
  if (score > 75) return "ХУБ";
  if (score > 50) return "ҚАНОАТБАХШ";
  if (score > 35) return "ҒАЙРИҚАНОАТБАХШ";
  return "БАД";
}
function shuffle(items) {
  const a = items.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function publicQuestions(player) {
  return player.questions.map((q, i) => ({ number: i + 1, q: q.q, options: q.o }));
}
function adminSession(req) {
  const s = sessions.get(String(req.headers["x-admin-token"] || ""));
  return s || null;
}
function playerSession(req) {
  const t = String(req.headers["x-player-token"] || "");
  for (const s of sessions.values()) {
    const p = [...s.players.values()].find(x => x.token === t);
    if (p) return {s, p};
  }
  return null;
}
function summary(s) {
  return [...s.players.values()].map(p => ({
    name: p.name, score: p.finished ? p.score : null,
    grade: p.finished ? p.grade : "Дар ҳоли иҷро",
    status: p.finished ? "Анҷом ёфт" : "Дар ҳоли иҷро",
    answered: p.answers.filter(x => x !== null).length
  })).sort((a,b) => (b.score ?? -1) - (a.score ?? -1));
}

app.post("/api/admin/create", (req, res) => {
  const password = String(req.body.password || "").trim();
  if (password.length < 4 || password.length > 40) return res.status(400).json({error:"Рамзи маъмур бояд аз 4 то 40 аломат бошад."});
  const id = token(), adminToken = token(), accessPin = pin();
  const s = {id, adminToken, passwordHash: crypto.createHash("sha256").update(password).digest("hex"),
    pin: accessPin, title:"Технологияи информатсионӣ", players:new Map(), createdAt:Date.now()};
  sessions.set(id, s);
  res.json({adminToken, pin:accessPin, title:s.title});
});

app.post("/api/admin/login", (req, res) => {
  const password = String(req.body.password || "");
  const hash = crypto.createHash("sha256").update(password).digest("hex");
  const s = [...sessions.values()].find(x => x.passwordHash === hash);
  if (!s) return res.status(401).json({error:"Рамзи маъмур нодуруст аст ё сервер аз нав оғоз шудааст."});
  res.json({adminToken:s.adminToken, pin:s.pin, title:s.title});
});

app.get("/api/admin/results", (req, res) => {
  const s = adminSession(req);
  if (!s) return res.status(401).json({error:"Иҷозат нест."});
  res.json({pin:s.pin, title:s.title, results:summary(s)});
});

app.post("/api/join", (req, res) => {
  const name = cleanName(req.body.name);
  const accessPin = String(req.body.pin || "").trim();
  if (name.length < 2) return res.status(400).json({error:"Ному насабро дуруст ворид кунед."});
  const s = [...sessions.values()].find(x => x.pin === accessPin);
  if (!s) return res.status(404).json({error:"Рамзи имтиҳон нодуруст аст ё имтиҳон фаъол нест."});
  const id = token();
  const questions = shuffle(QUESTION_BANK).map(q => {
    const order = shuffle([0,1,2,3]);
    return {q:q.q, o:order.map(i => q.o[i]), a:order.indexOf(q.a)};
  });
  const p = {id, token:token(), name, questions, answers:Array(20).fill(null), finished:false, score:0, grade:""};
  s.players.set(id,p);
  res.json({playerToken:p.token, questions:publicQuestions(p), title:s.title});
  io.to("admin:" + s.id).emit("results", summary(s));
});

app.post("/api/answer", (req, res) => {
  const found = playerSession(req);
  if (!found) return res.status(401).json({error:"Иштирокчӣ ёфт нашуд."});
  const {s,p} = found;
  if (p.finished) return res.status(400).json({error:"Имтиҳон аллакай анҷом ёфтааст."});
  const n = Number(req.body.number), choice = Number(req.body.choice);
  if (!Number.isInteger(n) || n < 0 || n >= 20 || !Number.isInteger(choice) || choice < 0 || choice > 3)
    return res.status(400).json({error:"Ҷавоб нодуруст аст."});
  p.answers[n] = choice;
  res.json({ok:true, answered:p.answers.filter(x=>x!==null).length});
});

app.post("/api/finish", (req, res) => {
  const found = playerSession(req);
  if (!found) return res.status(401).json({error:"Иштирокчӣ ёфт нашуд."});
  const {s,p} = found;
  if (!p.finished) {
    const correct = p.answers.reduce((n, answer, i) => n + (answer !== null && answer === p.questions[i].a ? 1 : 0), 0);
    p.score = correct * 5;
    p.grade = grade(p.score);
    p.finished = true;
  }
  io.to("admin:" + s.id).emit("results", summary(s));
  res.json({name:p.name, score:p.score, grade:p.grade, correct:p.score/5, total:20});
});

io.on("connection", socket => {
  socket.on("admin:watch", tokenValue => {
    const s = [...sessions.values()].find(x => x.adminToken === tokenValue);
    if (s) { socket.join("admin:" + s.id); socket.emit("results", summary(s)); }
  });
});

app.get(["/admin", "/play", "/"], (req,res) => res.sendFile(path.join(__dirname,"public","index.html")));
app.get("*", (req,res) => res.sendFile(path.join(__dirname,"public","index.html")));
server.listen(PORT, () => console.log(`Online Test System running on port ${PORT}`));
